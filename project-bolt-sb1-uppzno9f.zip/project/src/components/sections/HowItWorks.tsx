import React from 'react';

const HowItWorks: React.FC = () => {
  return (
    <section className="py-24">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-slate-800 rounded-lg p-6 h-full">
              <h3 className="text-xl font-semibold mb-4">Step 1: Connect</h3>
              <p className="text-slate-300">Connect your trading account and set your preferences.</p>
            </div>
          </div>
          <div className="text-center">
            <div className="bg-slate-800 rounded-lg p-6 h-full">
              <h3 className="text-xl font-semibold mb-4">Step 2: Analyze</h3>
              <p className="text-slate-300">Our AI algorithms analyze market data in real-time.</p>
            </div>
          </div>
          <div className="text-center">
            <div className="bg-slate-800 rounded-lg p-6 h-full">
              <h3 className="text-xl font-semibold mb-4">Step 3: Trade</h3>
              <p className="text-slate-300">Execute trades automatically based on AI insights.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;