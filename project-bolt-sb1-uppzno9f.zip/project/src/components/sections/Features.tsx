import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Shield, Cpu, BarChart3 } from 'lucide-react';

const features = [
  {
    icon: Zap,
    title: 'Lightning Fast Execution',
    description: 'Execute trades with microsecond precision, ensuring you never miss an opportunity.'
  },
  {
    icon: Shield,
    title: 'Bank-Grade Security',
    description: 'Your assets are protected with military-grade encryption and multi-layer security protocols.'
  },
  {
    icon: Cpu,
    title: 'AI-Powered Analysis',
    description: 'Advanced machine learning algorithms analyze market patterns in real-time.'
  },
  {
    icon: BarChart3,
    title: 'Advanced Analytics',
    description: 'Comprehensive data visualization and analysis tools to inform your trading decisions.'
  }
];

const Features = () => {
  return (
    <section className="py-24 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4">Powerful Features</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Experience the next generation of algorithmic trading with our cutting-edge features
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 hover:bg-slate-800/70 transition-colors"
              >
                <div className="bg-blue-500/10 p-3 rounded-lg w-fit mb-4">
                  <Icon className="w-6 h-6 text-blue-500" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </motion.div>
            )}
          )}
        </div>
      </div>
    </section>
  );
};

export default Features;